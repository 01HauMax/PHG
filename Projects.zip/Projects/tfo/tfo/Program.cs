﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace tfo
{
    class Program
    {
        static void Main(string[] args)
        {
            string a;
            string[] b;
            StreamReader sr = new StreamReader(@"TFO.csv");
            a = sr.ReadToEnd();
            sr.Close();
            a = a.Replace("\r\n",";");
            a = a.Replace(";;", "; ;");
            b = a.Split(';');
            Console.ForegroundColor = ConsoleColor.Black;
            for (int i = 0; i < b.Length-1; i = i + 3)
            {
                switch (b[i+1])
                {
                    case "9":
                        Console.BackgroundColor = ConsoleColor.Blue;                        
                        Console.Write(b[i]);
                        break;
                    case "12":
                        Console.BackgroundColor = ConsoleColor.Red;      
                        Console.Write(b[i]);
                        break;
                    default:
                        Console.BackgroundColor = ConsoleColor.Black;     
                        Console.Write(b[i]);
                        break;
                }
            }
            Console.ReadKey();
        }
    }
}
