﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace rdt
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, d;
            string c="";
            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());
            d = (a - b);
            c = c + d;
            d = (a + b - 1);
            c = c + d;
            Console.WriteLine(c);
            Console.ReadKey();

        }
    }
}
