﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace sin
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamWriter sw = new StreamWriter(@"H:/sin.csv");
            for (double i = 0; i <= Math.PI*2; i=i+Math.PI*2/1000)
            {
                Console.Write(i+"   ");
                Console.WriteLine(Math.Sin(i));
                sw.Write(i+";"+Math.Sin(i)+";\r");
            }
            sw.Close();
            Console.ReadKey();
        }
    }
}
