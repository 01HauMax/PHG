﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace @static
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal a, b=0;
            bool x = true;
            Console.WriteLine("╔════════════════════╗");
            Console.WriteLine("║ Zahl eingeben      ║");
            Console.WriteLine("╚════════════════════╝");
            a = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            while(x==true)
            {
                Console.WriteLine("╔════════════════════╗");
                Console.WriteLine("║ (1) plus           ║");
                Console.WriteLine("║ (2) subtrahieren   ║");
                Console.WriteLine("║ (3) multiplizieren ║");
                Console.WriteLine("║ (4) dividieren     ║");
                Console.WriteLine("║ (5) beenden        ║");
                Console.WriteLine("║ (6) fakultät       ║");
                Console.WriteLine("║ (7) quadratwurzel  ║");
                Console.WriteLine("╚════════════════════╝");
                var c = Console.ReadKey();
                Console.Clear();

                switch (c.Key)
                {
                    case ConsoleKey.D1:
                        b = z2();
                        Console.WriteLine(a+" + "+b+" = "+add(a,b));
                        a = add(a, b);
                        break;
                    case ConsoleKey.D2:
                        b = z2();
                        Console.WriteLine(a + " - " + b + " = " + sub(a, b));
                        a = sub(a, b);
                        break;
                    case ConsoleKey.D3:
                        b = z2();
                        Console.WriteLine(a + " * " + b + " = " + mul(a, b));
                        a = mul(a, b);
                        break;
                    case ConsoleKey.D4:
                        b = z2();
                        Console.WriteLine(a + " / " + b + " = " + div(a, b));
                        a = div(a, b);
                        break;
                    case ConsoleKey.D5:
                        x = false;
                        break;
                    case ConsoleKey.D6:
                        Console.WriteLine(a + "! = " + fak(a, b));
                        a = fak(a, b);
                        break;
                    case ConsoleKey.D7:
                        Console.WriteLine("sqrt(" + a + ") = " + qwu(a, b));
                        a = qwu(a, b);
                        break;

                }
            }
        }
        static decimal add(decimal a, decimal b)
        {
            decimal end;
            end = a + b;
            return end;
        }
        static decimal sub(decimal a, decimal b)
        {
            decimal end;
            end = a - b;
            return end;
        }
        static decimal mul(decimal a, decimal b)
        {
            decimal end;
            end = a * b;
            return end;
        }
        static decimal div(decimal a, decimal b)
        {
            decimal end;
            end = a / b;
            return end;
        }
        static decimal fak(decimal a, decimal b)
        {
            decimal end=1;
            for (decimal i = 1; i <= a; i++)
            {
                end *= i;
            }
            return end;     
        }
        static decimal qwu(decimal a, decimal b)
        {
            decimal end;
            end = Convert.ToDecimal(Math.Sqrt(Convert.ToDouble(a)));
            return end;
        }
        static decimal z2()
        {
            decimal end;
            Console.WriteLine("╔════════════════════╗");
            Console.WriteLine("║ Zahl eingeben      ║");
            Console.WriteLine("╚════════════════════╝");
            end = Convert.ToDecimal(Console.ReadLine());
            Console.Clear();
            return end;
        }
    }
}
