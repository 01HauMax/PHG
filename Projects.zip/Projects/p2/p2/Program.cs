﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace primzahlen
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(prim(i));
            Console.ReadKey();
        }
        static bool prim(int i)
        {
            bool a = false; ;
            int c = 0, k = 0;
            k = 2;
                while (k < i)
                {
                    c = 0;
                    c = i % k;
                    k = k + 1;
                    if (c == 0)
                    {
                        a = false;
                        k = i;
                    }
                    else if (k == i - 1 && c != 0)
                    {
                        a = true;
                    }
                }
                return a;
            }
        }
    }

