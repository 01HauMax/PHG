﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace matrix
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] a = new int[4, 4];
            int[,] k = new int[3, 3];
            bool b = false;
            bool s = false;
            bool l = false;
            bool v = true;
            int c = 0,yy,xx;
            char y = '0', x = '0';
            Random Rnd = new Random((int)DateTime.Now.Ticks);
            
            while (l == false)
            {
                c = 0;
                b = false;
                for (int i = 0; i < 4; i++)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write((char)(i + 64));
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write("  │");
                    for (int g = c; g < 4; g++)
                    {
                        if (g == 0 && b == false)
                        {
                            for (int t = 1; t < 4; t++)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.Write(t);
                                Console.ForegroundColor = ConsoleColor.White;
                                if (t < 4)
                                {
                                    Console.Write("  │");
                                }
                                else if (t < 40)
                                {
                                    Console.Write(" │");
                                }
                                else
                                {
                                    Console.Write("│");
                                }
                            }
                            b = true;
                            g = 4;
                            c = 1;
                        }

                        else
                        {
                            if (x == (char)(g + 48) && y == (char)(i + 64))
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                
                                if (s == true)
                                {
                                    k[i - 1, g - 1] = 1;
                                    Console.Write('X');
                                }
                                else
                                {
                                    k[i - 1, g - 1] = 2;
                                    Console.Write('O');
                                }
                            }
                            else if (x == (char)(g + 48) && y == (char)(i + 96))
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                if (s == true)
                                {
                                    k[i - 1, g - 1] = 1;
                                    Console.Write('X');
                                }
                                else
                                {
                                    k[i - 1, g - 1] = 2;
                                    Console.Write('O');
                                }
                            }
                            else if (k[i - 1, g - 1] == 1)
                            {
                                Console.ForegroundColor = ConsoleColor.White;
                                Console.Write('X');
                            }
                            else if (k[i - 1, g - 1] == 2)
                            {
                                Console.ForegroundColor = ConsoleColor.White;
                                Console.Write('O');
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Black;
                                Console.Write(" ");
                            }
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.Write("  " + "│");
                        }

                    }
                    Console.WriteLine();
                    Console.WriteLine("───┼───┼───┼───┤");
                }
                if (l == false&&s==false)
                {
                    x = Console.ReadKey().KeyChar;
                    y = Console.ReadKey().KeyChar;
                    Console.Clear();
                    s=true;
                }
                else if (l == false && s == true)
                {
                    do
                    {
                        v = true;
                        xx = Rnd.Next(1, 4);
                        yy = Rnd.Next(1, 4);
                        if (k[yy - 1, xx - 1] != 0)
                        {
                            v = false;
                        }
                        x = (char)(xx + 48);
                        y = (char)(yy + 64);
                    } while (v == false);
                    v = false;
                    Console.Clear();
                    s = false;
                }
            }
            Console.WriteLine("GAME OVER");
            Console.ReadKey();
        }
    }
}
