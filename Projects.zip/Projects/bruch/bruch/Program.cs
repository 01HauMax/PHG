﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace bruch
{
    class Program
    {
        static void Main(string[] args)
        {
            Bruch a=new Bruch();
            Bruch b = new Bruch();
            a.eingabe();
            a.ausgabe();
            a.erweitern(3);
            a.ausgabe();
            a.kehrwert();
            a.ausgabe();
            a.kürzen();
            a.ausgabe();
            b.eingabe();
            Console.ReadKey();
        }
    }
}

/*
 * zähler
 * nenner
 * 
 * kürzen
 * kehrwert
 * erweitern
 * eingabe
 * ausgabe
 * 
 * multi
 * add
*/