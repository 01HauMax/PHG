﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace bruch
{
    class Bruch
    {
        protected int zähler=1, nenner=1;

        public Bruch()
    {
        
    }
        public void eingabe()
        {
            Console.Clear();
            int zähler;
            int nenner;
            Console.Write("Zaehler: ");
            zähler = Convert.ToInt32(Console.ReadLine());
            Console.Write("Nenner: ");
            nenner = Convert.ToInt32(Console.ReadLine());
            this.zähler = zähler;
            this.nenner = nenner;
        }
        public void ausgabe()
        {
            Console.Clear();
            Console.WriteLine(zähler);
            if (zähler > 9 || nenner > 9)
            {
                Console.WriteLine("──");
            }
            else if (zähler > 99 || nenner > 99)
            {
                Console.WriteLine("───");
            }
            else
            {
                Console.WriteLine("─");
            }
            Console.WriteLine(nenner);
            Console.ReadKey();
        }
        public void erweitern(int e)
        {
            zähler = zähler * e;
            nenner = nenner * e;
        }
        public void kehrwert()
        {
            int a;
            a = zähler;
            zähler = nenner;
            nenner = a;
        }
        public void kürzen()
        {
            int a;
            if (zähler <= nenner)
            {
                a = zähler;
            }
            else
            {
                a = nenner;
            }
            for (int i = a; i > 0; i--)
            {
                if ((zähler / i) * i == zähler && (nenner / i) * i == nenner)
                {
                    zähler = zähler / i;
                    nenner = nenner / i;
                    i = 0;
                }
            }
        }+9
    }
}
