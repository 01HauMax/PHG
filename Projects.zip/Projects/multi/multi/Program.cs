﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace multi
{
    class Program
    {
        static void Main(string[] args)
        {
            char[,] p = new char[120, 60];
            Console.SetWindowSize(120, 60);
            Random Rnd = new Random((int)DateTime.Now.Ticks);
            int x = Rnd.Next(0, 60), y = Rnd.Next(0, 60);
            int g = 1;
            //I:\ALT\Hauser_Maximilian

            var c = Console.ReadKey(true);
            while (true)
            {
                System.Threading.Thread.Sleep(200);
                if (Console.KeyAvailable == true)
                    c = Console.ReadKey(true);

                switch (c.Key)
                {
                    case ConsoleKey.A:
                        if (x > 0)
                        {
                            Console.SetCursorPosition(x, y);
                            Console.Write(' ');
                            x = x - 1;
                            p[x, y] = ' ';
                        }
                        break;
                    case ConsoleKey.D:
                        if (x < 119)
                        {
                            Console.SetCursorPosition(x, y);
                            Console.Write(' ');
                            x = x + 1;
                            p[x, y] = ' ';
                        }
                        break;
                    case ConsoleKey.W:
                        if (y > 0)
                        {
                            Console.SetCursorPosition(x, y);
                            Console.Write(' ');
                            y = y - 1;
                            p[x, y] = ' ';
                        }
                        break;
                    case ConsoleKey.S:
                        if (y < 59)
                        {
                            Console.SetCursorPosition(x, y);
                            Console.Write(' ');
                            y = y + 1;
                            p[x, y] = ' ';
                        }
                        break;
                }
                Console.SetCursorPosition(x, y);
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write('O');
                Console.ForegroundColor = ConsoleColor.White;
                for (int i = 0; i < g; i++)
                {

                }
            }
        }
    }
}
