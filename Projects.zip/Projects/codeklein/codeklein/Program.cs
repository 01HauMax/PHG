﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace codeklein
{
    class Program
    {
        static void Main(string[] args)
        {
            //65-90
            //97-122
            Console.WriteLine("╔═══════════════════╗");
            Console.WriteLine("║ 1: Verschluesseln ║");
            Console.WriteLine("║ 2: Entschluesseln ║");
            Console.WriteLine("╚═══════════════════╝");
            var ab = Console.ReadKey();
            string a;
            char[] b;
            int d;
            Console.Clear();
            Console.Write("Text: ");
            a = Console.ReadLine();
            b = new char[a.Length];
            Console.Write("Code in Zahlen: ");
            d = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            Console.WriteLine(a);
            b = a.ToCharArray();
            switch (ab.Key)
            {
                case ConsoleKey.D1:
            for (int i = 0; i < a.Length; i++)
                        {
                            b[i] = ver(90, 65, b[i], d);
                            b[i] = ver(122, 97, b[i], d);
                            b[i] = ver(57, 48, b[i], d);
                            Console.Write(b[i]);
            }
                    break;
                case ConsoleKey.D2:
            for (int i = 0; i < a.Length; i++)
            {
                b[i] = ent(90, 65, b[i], d);
                b[i] = ent(122, 97, b[i], d);
                b[i] = ent(57, 48, b[i], d);
                Console.Write(b[i]);
            }
            break;
                default:
            break;
            }
            Console.ReadKey();
        }


        static char ver(int a, int b, char c, int d)
        {
            int x=26;
            if (a == 57)
            {
                x = 10;
            }
            if ((int)c <= a && (int)c >= b)
            {
                if ((int)c + d > a)
                {
                    c = (char)((int)c + d - x);
                }
                else
                {
                    c = (char)((int)c + d);
                }
            }
            return c;
        }

        static char ent(int a, int b, char c, int d)
        {
            int x = 26;
            if (a == 57)
            {
                x = 10;
            }
            if ((int)c <= a && (int)c >= b)
            {
                if ((int)c - d < b)
                {
                    c = (char)((int)c - d + x);
                }
                else
                {
                    c = (char)((int)c - d);
                }
            }
            return c;
        }
    }
    }
