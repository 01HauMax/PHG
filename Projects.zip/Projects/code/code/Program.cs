﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace code
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Text: ");
            string a = Console.ReadLine();
            char[] b = new char[a.Length];
            Console.Write("Code in Zahlen: ");
            int d = Convert.ToInt32(Console.ReadLine());
            int x, y;
            bool z = false;
            //48-122
            //91-96
            //58-64
            Console.Clear();
            Console.WriteLine(a);
            b = a.ToCharArray();
            while (z == false)
            {
                Console.Clear();
                z = true;
                for (int i = 0; i < a.Length; i++)
                {
                    x = (int)b[i];
                    if (x + d > 122 && x != 32)
                    {
                        y = (x + d) - 122 + 47;
                        b[i] = (char)(y);
                        Console.Write(b[i]);
                    }
                    else
                    {
                        if (x != 32)
                        {
                            b[i] = (char)(x + d);
                        }
                            Console.Write(b[i]);
                    }
                    x = (int)b[i];
                    if (x >= 58 && x <= 64 && x != 32)
                    {
                        z = false;
                    }
                    if (x > 122 && x != 32)
                    {
                        z = false;
                    }
                    if (x >= 91 && x <= 96 && x != 32)
                    {
                        z = false;
                    }
                }
            }
            Console.ReadKey();
        }
    }
}
