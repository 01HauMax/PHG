﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace formen
{
    class Program
    {
        static void Main(string[] args)
        {   

            Console.SetWindowSize(80,70);
            Console.WriteLine("l : Linie");
            Console.WriteLine("d : Dreieck");
            Console.WriteLine("k : Kreis");
            char f = Console.ReadKey().KeyChar;
            Console.Clear();
            Console.WriteLine("Zeichen");
            char ze = Console.ReadKey().KeyChar;
            Console.WriteLine();
            Console.WriteLine("Farbe");
            int fa = Convert.ToInt32(Console.ReadLine());
            Console.ForegroundColor = (System.ConsoleColor)fa;
            Console.Clear();
            Console.Write("╔══════════════════════════════════════════════════════════════════════════════╗");
            for (int i = 0; i < 41; i++)
            {
                Console.Write("║                                                                              ║");  
            }
            Console.WriteLine("╚══════════════════════════════════════════════════════════════════════════════╝");
            
            if (f == 'd')
            {
                int x1, y1,x2,y2, x3, y3;
                Console.Write("x1 = ");
                x1 = Convert.ToInt32(Console.ReadLine());
                Console.Write("y1 = ");
                y1 = Convert.ToInt32(Console.ReadLine());
                Console.Write("x2 = ");
                x2 = Convert.ToInt32(Console.ReadLine());
                Console.Write("y2 = ");
                y2 = Convert.ToInt32(Console.ReadLine());
                Console.Write("x3 = ");
                x3 = Convert.ToInt32(Console.ReadLine());
                Console.Write("y3 = ");
                y3 = Convert.ToInt32(Console.ReadLine());
                l(x1, y1, x2, y2,ze);
                l(x1, y1, x3, y3, ze);
                l(x2, y2, x3, y3, ze);
            }
            else if (f == 'l')
            {
                int x1, y1, x2, y2;
                Console.Write("x1 = ");
                x1 = Convert.ToInt32(Console.ReadLine());
                Console.Write("y1 = ");
                y1 = Convert.ToInt32(Console.ReadLine());
                Console.Write("x2 = ");
                x2 = Convert.ToInt32(Console.ReadLine());
                Console.Write("y2 = ");
                y2 = Convert.ToInt32(Console.ReadLine());
                l(x1, y1, x2, y2,ze);
            }
            else if (f == 'k')
            {
                int x1, y1, x;
                Console.Write("x = ");
                x1 = Convert.ToInt32(Console.ReadLine());
                Console.Write("y = ");
                y1 = Convert.ToInt32(Console.ReadLine());
                Console.Write("Durchmesser = ");
                x = Convert.ToInt32(Console.ReadLine());
                k(x1, y1, x,ze);
                
            }
            Console.ReadKey();
            }

        static void l(int x1, int y1, int x2, int y2, char ze)
        {
            int gx, gy, iy, ix, ix2, iy2;
            int h, b;
            double z;
            bool o = false;

            if (x1 < x2)
            {
                b = x2 - x1;
                if (y1 < y2)
                {
                    gx = x1;
                    o = true;
                }
                else
                {
                    gx = x2;
                    o = false;
                }
                ix = x1;
                ix2 = x2;
            }
            else
            {
                b = x1 - x2;
                if (y1 > y2)
                {
                    gx = x2;
                    o = true;
                }
                else
                {
                    gx = x1;
                    o = false;
                }
                ix = x2;
                ix2 = x1;
            }
            if (y1 < y2)
            {
                h = y2 - y1;
                iy = y1;
                iy2 = y2;
                gy = y1;
            }
            else
            {
                h = y1 - y2;
                iy = y2;
                iy2 = y1;
                gy = y2;
            }

            z = Convert.ToDouble(h) / Convert.ToDouble(b);
            Console.SetCursorPosition(x2, y2);
            Console.Write(ze);
            Console.SetCursorPosition(x1, y1);
            Console.Write(ze);
            double c = 0;
            if (z >= 1)
            {
                for (int i = iy + 1; i <= iy2; i++)
                {
                    if (c >= z)
                    {
                        if (o == true)
                        {
                            if (c == z)
                            {
                                gx = gx + 1;
                                c = 0;
                            }
                            else
                            {
                                gx = gx + 1;
                                c = c - z;
                            }
                        }
                        else
                        {
                            if (c == z)
                            {
                                gx = gx - 1;
                                c = 0;
                            }
                            else
                            {
                                gx = gx - 1;
                                c = c - z;
                            }
                        }
                    }
                    Console.SetCursorPosition(gx, i);
                    Console.Write(ze);
                    c = c + 1;
                }
            }
            else
            {
                z = Convert.ToDouble(b) / Convert.ToDouble(h);
                for (int i = ix + 1; i <= ix2; i++)
                {

                    if (c >= z)
                    {
                        if (o == true)
                        {
                            if (c == z)
                            {
                                gy = gy + 1;
                                c = 0;
                            }
                            else
                            {
                                gy = gy + 1;
                                c = c - z;
                            }
                        }
                        else
                        {
                            if (c == z)
                            {
                                gy = gy - 1;
                                c = 0;
                            }
                            else
                            {
                                gy = gy - 1;
                                c = c - z;
                            }
                        }
                        
                    }
                    Console.SetCursorPosition(i, gy);
                    Console.Write(ze);
                    c = c + 1;
                }
            }
        }
        static void k(int x1,int y1,int x,char ze)
        {
            for (int i = 0; i < 100000;i++ )
            {
                double g = (Math.Sin(i)*x) + x1;
                double g2 = (Math.Cos(i)*x) + y1;
                Console.SetCursorPosition(Convert.ToInt32(g), Convert.ToInt32(g2));
                Console.Write(ze);
            }
        }
                
        }
    }

