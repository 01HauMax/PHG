﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApplication14
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                
                //Console.WriteLine(line);
                
                Console.WriteLine("╔═══════════════════╗");
                Console.WriteLine("║ 1: Verschluesseln ║");
                Console.WriteLine("║ 2: Entschluesseln ║");
                Console.WriteLine("╚═══════════════════╝");
                var ab = Console.ReadKey();
                string an="", file;
                char[] b;
                int d;
                Console.Clear();
                Console.Write("Pfad zu Datei angeben: ");
                file = Console.ReadLine();
                StreamReader sr = new StreamReader(file); // Open the text file using a stream reader.
                string a = sr.ReadToEnd();
                switch (ab.Key)
                {
                    case ConsoleKey.D1:
                        sr.Close();
                        b = new char[a.Length];
                        Console.Write("Code in Zahlen: ");
                        d = Convert.ToInt32(Console.ReadLine());
                        Console.Clear();
                        //Console.WriteLine(a);
                        b = a.ToCharArray();
                        for (int i = 0; i < a.Length; i++)
                        {
                            if ((int)b[i] <= 90 && (int)b[i] >= 65)
                            {
                                    if ((int)b[i] + d > 90)
                                    {
                                        b[i] = (char)((int)b[i] + d - 26);
                                    }
                                    else
                                    {
                                        b[i] = (char)((int)b[i] + d);
                                    }
                                    while (b[i] > 90 || b[i] < 65)
                                    {
                                        b[i] = (char)((int)b[i] - 26);
                                    }
                            }
                            if ((int)b[i] <= 122 && (int)b[i] >= 97)
                            {
                                
                                if ((int)b[i] + d > 122)
                                {
                                    b[i] = (char)((int)b[i] + d - 26);
                                }
                                else
                                {
                                    b[i] = (char)((int)b[i] + d);
                                }
                                while (b[i] > 122 || b[i] < 97)
                                {
                                    b[i] = (char)((int)b[i] - 26);
                                }
                            }
                            if ((int)b[i] <= 57 && (int)b[i] >= 48)
                            {
                                if ((int)b[i] + d > 57)
                                {
                                    b[i] = (char)((int)b[i] + d + 10);
                                }
                                else
                                {
                                    b[i] = (char)((int)b[i] + d);
                                }
                                while (b[i] > 57 || b[i] < 48)
                                    {
                                        b[i] = (char)((int)b[i] - 26);
                                    }
                            }
                            an =an + b[i];
                            Console.Write(b[i]);
                        }
                        break;
                    case ConsoleKey.D2:
                        sr.Close();
                        b = new char[a.Length];
                        Console.Write("Code in Zahlen: ");
                        d = Convert.ToInt32(Console.ReadLine());
                        Console.Clear();
                        //Console.WriteLine(a);
                        b = a.ToCharArray();
                        for (int i = 0; i < a.Length; i++)
                        {
                            if ((int)b[i] <= 90 && (int)b[i] >= 65)
                            {
                                if ((int)b[i] - d < 65)
                                {
                                    b[i] = (char)((int)b[i] - d + 26);
                                }
                                else
                                {
                                    b[i] = (char)((int)b[i] - d);
                                }
                                while (b[i] > 90 || b[i] < 65)
                                {
                                    b[i] = (char)((int)b[i] + 26);
                                }
                            }
                            if ((int)b[i] <= 122 && (int)b[i] >= 97)
                            {
                                if ((int)b[i] - d < 97)
                                {
                                    b[i] = (char)((int)b[i] - d + 26);
                                }
                                else
                                {
                                    b[i] = (char)((int)b[i] - d);
                                }
                                while (b[i] > 122 || b[i] < 97)
                                {
                                    b[i] = (char)((int)b[i] + 26);
                                }
                            }
                            if ((int)b[i] <= 57 && (int)b[i] >= 48)
                            {
                                if ((int)b[i] - d < 48)
                                {
                                    b[i] = (char)((int)b[i] - d + 10);
                                }
                                else
                                {
                                    b[i] = (char)((int)b[i] - d);
                                }
                                while (b[i] > 57 || b[i] < 48)
                                {
                                    b[i] = (char)((int)b[i] + 26);
                                }
                            }
                            an = an + b[i];
                            Console.Write(b[i]);
                        }
                        break;
                    default:
                        break;
                }

                
                    try
                    {                        
                        StreamWriter sw = new StreamWriter(file);    //Pass the filepath and filename to the StreamWriter Constructor
                        sw.WriteLine("\r\r"+an);                                       //Write a line of text                    
                        sw.Close();                                             //Close the file
                    }
                    catch (Exception e)
                    { Console.WriteLine("Exception: " + e.Message); }           //Bei einm Fehler erscheint diese Meldung
                

                sr.Close();                                                     //Close the file
            }
            catch (Exception e)
            {
                Console.WriteLine("The file could not be read:");               //Bei einm Fehler erscheint diese Meldung
                Console.WriteLine(e.Message);
            }
            Console.ReadKey();


        }
}
    }

