﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace auto
{
    public class Auto
    {
        public string marke;
        public int ps;
        public int ver;
        public string farbe;
        public int tank;
        protected int tanki=0;
        protected int km;
        public int a=0;

        public void Info()
        {
            Console.WriteLine("Marke: "+marke);
            Console.WriteLine("PS: " + ps);
            Console.WriteLine("Farbe: " + farbe);
            Console.WriteLine("Km gefahren: " + km);
            Console.WriteLine("Tank: " + (100*tanki)/tank+"%");
            Console.WriteLine("Reichweite: " + Convert.ToInt32(Convert.ToDouble(tanki / (Convert.ToDouble(ver) / 100.0))));
        }
        public void Tanken(int a)
        {
            tanki = tanki + a;
            if (tanki >= tank)
            {
                tanki = tank;
            }
        }
        public void Fahren(int a)
        {
            if (tanki - Convert.ToInt32((Convert.ToDouble(ver) / 100) * a) >= 0)
            {
                km = km + a;
                tanki = tanki - Convert.ToInt32((Convert.ToDouble(ver) / 100) * a);
            }
            else
            {
                if (tanki > 0)
                {
                    km = Convert.ToInt32(Convert.ToDouble(tanki/(Convert.ToDouble(ver) / 100.0)));
                    a = Convert.ToInt32(Convert.ToDouble(tanki / (Convert.ToDouble(ver) / 100.0)));
                }
                else
                {
                    km = km + 0;
                    a = 0;
                }
                tanki = 0;
            }
            this.a = a;
        }

        public void animation()
        {
            int b = a;
            string dr = "";
            if (a != 0)
            {
                for (int i = 0; i < 15; i++)
                {
                    Console.Clear();
                    Console.WriteLine(dr+"┌────┬──┐");
                    Console.WriteLine(dr+"├────┴──┴───┐");
                    Console.WriteLine(dr+"└(─)─────(─)┘");
                    Console.WriteLine(" ██████████████████████████████████████████████████████████████████████████");
                    dr = dr + " ";
                    System.Threading.Thread.Sleep(70);
                    Console.Clear();
                    Console.WriteLine(dr+"┌────┬──┐");
                    Console.WriteLine(dr+"├────┴──┴───┐");
                    Console.WriteLine(dr + "└(" + (char)92 + ")─────(" + (char)92 + ")┘");
                    Console.WriteLine(" ██████████████████████████████████████████████████████████████████████████");
                    System.Threading.Thread.Sleep(70);
                    dr = dr + " ";
                    Console.Clear();
                    Console.WriteLine(dr + "┌────┬──┐");
                    Console.WriteLine(dr + "├────┴──┴───┐");
                    Console.WriteLine(dr + "└(│)─────(│)┘");
                    Console.WriteLine(" ██████████████████████████████████████████████████████████████████████████");
                    dr = dr + " ";
                    System.Threading.Thread.Sleep(70);
                    Console.Clear();
                    Console.WriteLine(dr + "┌────┬──┐");
                    Console.WriteLine(dr + "├────┴──┴───┐");
                    Console.WriteLine(dr + "└(/)─────(/)┘");
                    Console.WriteLine(" ██████████████████████████████████████████████████████████████████████████");
                    System.Threading.Thread.Sleep(70);
                    dr = dr + " ";
                }
            }
        }

        public Auto(string marke, string farbe, int ps, int ver, int tank)
        {
            this.marke = marke;
            this.ps = ps;
            this.ver = ver;
            this.farbe = farbe;
            this.tank = tank;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            /*string marke;
            int ps;
            int ver;
            string farbe;
            int tank;
            Console.Write("Marke: ");
            marke = Console.ReadLine();
            Console.Write("Farbe: ");
            farbe = Console.ReadLine();
            Console.Write("PS: ");
            ps = Convert.ToInt32(Console.ReadLine());
            Console.Write("Verbrauch pro 100km: ");
            ver = Convert.ToInt32(Console.ReadLine());
            Console.Write("Tankgroesse: ");
            tank = Convert.ToInt32(Console.ReadLine());
            Auto auto1 = new Auto(marke,farbe,ps,ver,tank);
            Console.Clear();*/
            Auto auto1 = new Auto("VW", "Rot", 55, 12, 40);
            while (true)
            {
                switch (Console.ReadLine())
                {
                    case "info":
                        auto1.Info();
                        Console.ReadKey();
                        break;
                    case "tanken":
                        Console.WriteLine("Wieviel wollen sie tanken?");
                        auto1.Tanken(Convert.ToInt32(Console.ReadLine()));
                        Console.WriteLine("OK");
                        System.Threading.Thread.Sleep(500);
                        break;
                    case "fahren":
                        Console.WriteLine("Wie weit vollen sie fahren?");
                        auto1.Fahren(Convert.ToInt32(Console.ReadLine()));
                        Console.WriteLine("OK");
                        System.Threading.Thread.Sleep(500);
                        auto1.animation();
                        break;
                }
                Console.Clear();
            }
        }
    }
}
