﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace abcver
{
    class Program
    {
        static void Main(string[] args)
        {
            char[,] a = new char[2, 26];
            char[] c = new char[26];
            char[] d = new char[26];
            char[] z;
            string code="", txt="", pfad="";
            char b;
            int h = 0;
            
            //Random Rnd = new Random();

            for (int i = 97; i < 123; i++)
            {
                a[0, i-97] = (char)i;
            }
            for (int i = 65; i < 91; i++)
            {
                a[1, i-65] = (char)i;
            }

            Console.WriteLine("╔═══════════════════╗");
            Console.WriteLine("║ 1: Verschluesseln ║");
            Console.WriteLine("║ 2: Entschluesseln ║");
            Console.WriteLine("╚═══════════════════╝");
            var f = Console.ReadKey();
            Console.Clear();
            Console.WriteLine("╔═══════════════════╗");
            Console.WriteLine("║   CODE EINGEBEN   ║");
            Console.WriteLine("╚═══════════════════╝");
            Console.Write(": ");
            code = Console.ReadLine();
            Console.Clear();
            Console.WriteLine("╔═══════════════════╗");
            Console.WriteLine("║ 1: .txt Datei     ║");
            Console.WriteLine("║ 2: Text eingeben  ║");
            Console.WriteLine("╚═══════════════════╝");
            var l = Console.ReadKey();
            Console.Clear();
            if (l.Key == ConsoleKey.D1)
            {
                Console.WriteLine("╔═══════════════════╗");
                Console.WriteLine("║   PFAD ZU .TXT    ║");
                Console.WriteLine("╚═══════════════════╝");
                Console.Write(": ");
                pfad = Console.ReadLine();
            }
            else
            {
                Console.WriteLine("╔═══════════════════╗");
                Console.WriteLine("║   Text eingeben   ║");
                Console.WriteLine("╚═══════════════════╝");
                Console.Write(": ");
                txt = Console.ReadLine();
            }
            Console.Clear();

            for (int i = 0; i < code.Length; i++)
            {
                c[i] = code[i];
            }

            for (int i = 0; i < code.Length; i++)
            {
                b = c[i];
                for (int g = i+1; g < code.Length; g++)
                {
                    if(c[g]==b)
                    {
                        c[g] = '\0';
                        code = new string(c);
                        code = code.Replace("\0", "");
                        c = new char[26];

                        for (int x = 0; x < code.Length; x++)
                        {                            
                            c[x] = code[x];
                        }
                    }
                    if(c[g]=='\0')
                    {
                        a[2, i] = (char)(g+65);
                    }
                }
            }

            c = new char[26];

            for (int i = 0; i < code.Length; i++)
            {
                c[i] = code[i];
            }
            for (int i = code.Length+97; i < 123; i++)
            {
                if(c[i-97]=='\0')
                {
                    for (int g = 0; g < code.Length; g++)
                    {
                        if(c[g] == (char)(i-code.Length+h))
                        {
                            h = h + 1;
                        }
                    }
                    c[i-97] = (char)(i-code.Length+h);
                }
            }
            if (l.Key == ConsoleKey.D1)
            {
                StreamReader sr = new StreamReader(pfad);
                txt = sr.ReadToEnd();
                sr.Close();
            }
            z = new char[txt.Length];
            z = txt.ToCharArray();
            for (int i = 0; i < txt.Length; i++)
            {
                for (int g = 0; g < 26; g++)
                {
                    if (f.Key == ConsoleKey.D1)
                    {
                        if (z[i] == a[0, g] || z[i] == a[1, g])
                        {
                            z[i] = c[g];
                            g = 26;
                        }
                    }
                    if (f.Key == ConsoleKey.D2)
                    {
                        if (z[i] == c[g])
                        {
                            z[i] = a[0,g];
                            g = 26;
                        }
                    }
                }
            }

            txt = new string(z);
            txt = txt.Replace("\0", "");
            if (l.Key == ConsoleKey.D1)
            {
                StreamWriter sw = new StreamWriter(pfad);
                sw.WriteLine(txt);
                sw.Close();
            }
            Console.WriteLine("╔═══════════════════╗");
            Console.WriteLine("║   ABGESCHLOSSEN   ║");
            Console.WriteLine("╚═══════════════════╝");
            if(l.Key==ConsoleKey.D1)
            {
                Console.WriteLine(": "+txt);
            }
            Console.ReadKey();
        }
    }
}
