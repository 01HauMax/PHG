﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace stoppuhr
{
    public partial class tim : Form
    {
        int c = 0;
        int c1 = 0;
        int c2 = 0;

        public tim()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (StartStop.Text == "Stop")
            {
                timer1.Enabled = false;
                c = 0;
                c1 = 0;
                c2 = 0;
                Pause.Enabled = false;
                StartStop.Text = "Start";
            }
            else
            {
                timer1.Enabled = true;
                Pause.Enabled = true;
                StartStop.Text = "Stop";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled == true)
            {
                timer1.Enabled = false;
            }
            else
            {
                timer1.Enabled = true;
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            c++;
            if (c == 99)
            {
                c = 0;
                c1++;
            }
            if (c1 == 59)
            {
                c1 = 0;
                c2++;
            }
           label1.Text = c2.ToString("D2") + ":" + c1.ToString("D2") + ":" + c.ToString("D2");
        }
        private void tim_Load(object sender, EventArgs e)
        {
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        
    }
}
