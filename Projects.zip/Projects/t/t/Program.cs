﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace t
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime startzeit = DateTime.Now;


            TimeSpan time = DateTime.Now - startzeit;
            Console.WriteLine("Programmdauer: {0}ms",time);
        }
    }
}
