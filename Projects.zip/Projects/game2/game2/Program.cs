﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace game2
{
    public class Player
    {
        protected string Name;
        //private int Level;
        public int x;
        public int y;

        public Player()
        {
            Name = "Player_1";
            //Level = 0;
        }

        public Player(string a)
        {
            Name = a;
            //Level = 0;
        }

        ~Player()
        {
            Console.WriteLine("Ciao!");
        }

        public void write()
        {
            Console.SetCursorPosition(x, y);
            Console.Write("o");
            Console.SetCursorPosition(x, y+1);
            Console.Write("|");
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Player Hero = new Player();
            int y = 0;
            var c = Console.ReadKey(true);
            while (true)
            {
                //if (Console.KeyAvailable == true)
                //c = Console.ReadKey(true);
                if ((Control.ModifierKeys & Keys.Shift) != 0) 
                switch (c.Key)
                {
                    case ConsoleKey.Spacebar:
                        y = Hero.y;
                        Hero.y = 0;
                        if (y == Hero.y)
                        {
                            Hero.y = 1;
                        }
                        break;
                    default:
                        Hero.y = 1;
                        break;
                }
                
                Hero.write();
                System.Threading.Thread.Sleep(300);
                Hero.x = Hero.x + 1;
                Console.Clear();
            }

            Console.ReadKey();
        }
    }
}
