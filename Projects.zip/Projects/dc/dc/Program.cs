﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace dc
{
    class Program
    {
        static void Main(string[] args)
        {
            string a = "Drei Chinesen mit dem Kontrabass saßen auf der Straße und erzählten sich was. Da kam die Polizei, fragt: „Was ist denn das?“ Drei Chinesen mit dem Kontrabass.";
                Console.WriteLine(a);
                Console.WriteLine();
                a = a.Replace("ei","a");
                a = a.Replace("a", "a");
                a = a.Replace("e", "a");
                a = a.Replace("i", "a");
                a = a.Replace("o", "a");
                a = a.Replace("u", "a");
                Console.WriteLine(a);
                Console.WriteLine();
                a = a.Replace("a", "ö");
                Console.WriteLine(a);
                Console.WriteLine();
                a = a.Replace("ö", "au");
                Console.WriteLine(a);
                Console.WriteLine();
                Console.ReadKey();
        }
    }
}
