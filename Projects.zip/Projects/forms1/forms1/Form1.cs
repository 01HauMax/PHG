﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace forms1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            int y = mh1.Location.Y;
            for (int i = 0; i < y; i++)
            {
                mh1.Location = new Point(mh1.Location.X, y);
                System.Threading.Thread.Sleep(30);
                y = y + 1;
            }
        }

        private void toolStripDropDownButton1_Click(object sender, EventArgs e)
        {
            
        }

        private void Start_Click(object sender, EventArgs e)
        {
            bd1.HideDropDown();
            //int x = 238;
            //for (int i = 0; i < 238; i++)
            //{
            //    mh1.Location = new Point(x, 30);
            //    System.Threading.Thread.Sleep(30);
            //    x = x - 1;
            }
        }
    }
}
