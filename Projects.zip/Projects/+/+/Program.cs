﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _
{
    class Program
    {
        static void Main(string[] args)
        {
            string c = "";
            int a = 0,d=0;
            while (true)
            {
                var b = Console.ReadKey();
                switch (Convert.ToString(b.KeyChar))
                {
                    case "+":
                        switch (d)
                        {
                            case 1:
                                a = a + Convert.ToInt32(c);
                                break;
                            case 2:
                                a = a - Convert.ToInt32(c);
                                break;
                            case 3:
                                a = a * Convert.ToInt32(c);
                                break;
                            case 4:
                                a = a / Convert.ToInt32(c);
                                break;
                            default:
                                a = Convert.ToInt32(c);
                                break;
                        }
                        d = 1;
                        c = "";
                        break;
                    case "-":
                        switch (d)
                        {
                            case 1:
                                a = a + Convert.ToInt32(c);
                                break;
                            case 2:
                                a = a - Convert.ToInt32(c);
                                break;
                            case 3:
                                a = a * Convert.ToInt32(c);
                                break;
                            case 4:
                                a = a / Convert.ToInt32(c);
                                break;
                            default:
                                a = Convert.ToInt32(c);
                                break;
                        }
                        d = 2;
                        c = "";
                        break;
                    case "*":
                        switch (d)
                        {
                            case 1:
                                a = a + Convert.ToInt32(c);
                                break;
                            case 2:
                                a = a - Convert.ToInt32(c);
                                break;
                            case 3:
                                a = a * Convert.ToInt32(c);
                                break;
                            case 4:
                                a = a / Convert.ToInt32(c);
                                break;
                            default:
                                a = Convert.ToInt32(c);
                                break;
                        }
                        d = 3;
                        c = "";
                        break;
                    case "/":
                        switch (d)
                        {
                            case 1:
                                a = a + Convert.ToInt32(c);
                                break;
                            case 2:
                                a = a - Convert.ToInt32(c);
                                break;
                            case 3:
                                a = a * Convert.ToInt32(c);
                                break;
                            case 4:
                                a = a / Convert.ToInt32(c);
                                break;
                            default:
                                a = Convert.ToInt32(c);
                                break;
                        }
                        d = 4;
                        c = "";
                        break;
                    case "=":
                        switch (d)
                        {
                            case 1:
                                a = a + Convert.ToInt32(c);
                                break;
                            case 2:
                                a = a - Convert.ToInt32(c);
                                break;
                            case 3:
                                a = a * Convert.ToInt32(c);
                                break;
                            case 4:
                                a = a / Convert.ToInt32(c);
                                break;
                        }
                        Console.Write(a);
                        d = 0;
                        c = Convert.ToString(a);
                        break;
                    default:
                        c = c + Convert.ToString(b.KeyChar);
                        break;
                }
            }
        }
    }
}
