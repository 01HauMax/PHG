﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace klassen_vererben
{
    class tiere
    {
        public int kg, cm, jahre;
        /*public tiere(int kg, int cm, int jahre)
        {
            this.kg = kg;
            this.cm = cm;
            this.jahre = jahre;
        }*/
    }
    class vögel : tiere
    {
        public int fcm;
        public vögel(int kg, int cm, int jahre, int fcm)
        {
            this.kg = kg;
            this.cm = cm;
            this.jahre = jahre;
            this.fcm = fcm;
        }
    }
    class wirbeltiere : tiere
    {
        public string ff;
        /*public wirbeltiere(int kg, int cm, int jahre, int s1)
        {
            this.kg = kg;
            this.cm = cm;
            this.jahre = jahre;
            this.ff = s1;
        }*/
    }
    class fische : tiere
    {
        public int flossen;
        public fische(int kg, int cm, int jahre, int flossen)
        {
            this.kg = kg;
            this.cm = cm;
            this.jahre = jahre;
            this.flossen = flossen;
        }
    }

    class mensch : wirbeltiere
    {
        public string vor, nac;
        public mensch(int kg, int cm, int jahre, string fellfarbe, string vor, string nac)
        {
            this.kg = kg;
            this.cm = cm;
            this.jahre = jahre;
            this.ff = fellfarbe;
            this.vor = vor;
            this.nac = nac;
        }
    }
    class haustiere : wirbeltiere
    {
        public string vor;
        public haustiere(int kg, int cm, int jahre, string fellfarbe, string name)
        {
            this.kg = kg;
            this.cm = cm;
            this.jahre = jahre;
            this.ff = fellfarbe;
            this.vor = name;
        }
    }
}
