﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace klassen_vererben
{
    class Program
    {
        static void Main(string[] args)
        {
            mensch a = new mensch(60,170,20,"rot","Maxi","Hauser");
        }
    }
}
