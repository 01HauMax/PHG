﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace temp
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader sr = new StreamReader(@"H:/TempMeran2016.csv");
            string[,] a = new string[12,4]; 
            string b=sr.ReadToEnd(),c;
            string[] x = b.Split(';');
            sr.Close();
            int g = 0,g2=1;

            a[0, 0] = "Jaener";
            a[1, 0] = "Februar";
            a[2, 0] = "Maerz";
            a[3, 0] = "April";
            a[4, 0] = "Mai";
            a[5, 0] = "Juni";
            a[6, 0] = "Juli";
            a[7, 0] = "August";
            a[8, 0] = "September";
            a[9, 0] = "Oktober";
            a[10, 0] = "November";
            a[11, 0] = "Dezember";

            for (int i = 0; i < 12; i++)
            {
                    a[i,g2]=x[g];
                    Console.Write(a[i, g2]+" # ");
                    g++; g2++;
                    a[i, g2] = x[g];
                    Console.Write(a[i, g2]+" # ");
                    g++; g2++;
                    a[i, g2] = Convert.ToString((Convert.ToDouble(x[g-2]) + Convert.ToDouble(x[g-1])) / 2);
                    Console.Write(a[i, g2]);
                    g2 = 0;
                    Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
