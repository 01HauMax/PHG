﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace u9
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader sr = new StreamReader(@"H:\09Uebung.txt");
            string a = sr.ReadToEnd();
            sr.Close();
            string b;
            a = a.Replace("150","200");
            a = a.ToLower();
            a = a.Replace(" ","");
            a = a.Replace("	", "");
            a = a.Replace(';', ' ');
            a = a.Replace(':', ' ');
            a = a.Replace("?","ae");
            for (int i = 0; i < a.Length; i++)
            {
                if(a[i]==' ')
                {
                    b = a[i + 1].ToString();
                    a = a.Remove(i+1,1);
                    b = b.ToUpper();
                    a = a.Insert(i+1,b);
                }
            }
                Console.WriteLine(a);
                StreamWriter sw = new StreamWriter(@"H:\09Uebung.txt");    //Pass the filepath and filename to the StreamWriter Constructor
                sw.WriteLine(a);                                       //Write a line of text                    
                sw.Close(); 
            Console.ReadKey();
        }
    }
}
