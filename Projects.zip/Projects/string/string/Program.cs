﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace @string
{
    class Program
    {
        static void Main(string[] args)
        {
            string a = "AbCdEfGh<> ,,";
            Console.WriteLine(a);
            Console.WriteLine(a.ToLower());
            Console.WriteLine(a.ToUpper());
            Console.WriteLine(a.Trim('A',','));
            Console.WriteLine(a.Substring(2,3));
            Console.ReadKey();
        }
    }
}
