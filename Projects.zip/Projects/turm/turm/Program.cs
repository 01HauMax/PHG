﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace turm
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 5;
            //int n = Convert.ToInt32(Console.ReadLine());
            int[] a = new int[n];
            int[] b = new int[n];
            int[] c = new int[n];
            int[] x = new int[n];
            for (int i = 0; i < n; i++)
            {
                a[i] = i+1;
                x[i] = a[i];
            }
            w(a, b, c, n);
            int ai = 0;
            int bi = n - 1;
            int ci = n - 1;
            while (b != x)
            {
                    System.Threading.Thread.Sleep(1000);
                    
                    w(a, b, c, n);
                    
            }

            Console.ReadKey();
        }

        static void w(int[] a, int[] b, int[] c, int n)
        {
            Console.Clear();
            for (int g = 0; g < n; g++)
            {
                Console.Write(a[g] + " ");
                Console.Write(b[g] + " ");
                Console.WriteLine(c[g]);
            }
        }
                }
            }
