﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace road
{
    class Program
    {
        static void Main(string[] args)
        {
            char[,] r = new char[30, 30];

        }
    }
}
